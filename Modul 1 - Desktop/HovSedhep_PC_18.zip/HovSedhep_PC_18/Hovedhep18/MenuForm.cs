﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hovedhep18
{
    using static GlobalVariables;
    public partial class MenuForm : Form
    {
        int selectId;
        public MenuForm()
        {
            InitializeComponent();
        }

        private void MenuForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hovSedhepDatabaseDataSet1.Categories' table. You can move, or remove it, as needed.
            this.categoriesTableAdapter.Fill(this.hovSedhepDatabaseDataSet1.Categories);
            this.loadData();
        }

        public void loadData()
        {
            menuGridView.Rows.Clear();
            int id = 0;
            var menuItems = db.MenuItems.ToList();
            if (selectId == 0)
            {
                db.MenuItems.Where(d => d.Name.Contains(textBoxSearch.Text) && d.CategoryID == (int)comboBoxCategory.SelectedValue).ToList().ForEach(d =>
                {
                    var menuId = d.MenuItemID;
                    var category = db.Categories.Where(c => c.CategoryID == d.CategoryID).Select(c => c.Name).FirstOrDefault();
                    var name = d.Name;
                    var price = d.Price;
                    var description = d.Description;
                    object[] obj = new object[] { menuId, category, name, price,  description };
                    menuGridView.Rows.Add(obj);
                });
            }
            else
            {
                db.MenuItems.ToList().ForEach(d =>
                {
                    var menuId = d.MenuItemID;
                    var category = db.Categories.Where(c => c.CategoryID == d.CategoryID).Select(c => c.Name).FirstOrDefault();
                    var name = d.Name;
                    var price = d.Price;
                    var description = d.Description;
                    object[] obj = new object[] { menuId, category, name, price, description };
                    menuGridView.Rows.Add(obj);
                });
            }
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            if (comboBoxCategory.SelectedIndex == -1)
            {
                MessageBox.Show("Please Enter A Category");
            }
            if (textBoxSearch.Text.Length == 0)
            {
                MessageBox.Show("Please Enter A Menu Item Name");
            }
            else
            {
            loadData();
            }
        }
    }
}
