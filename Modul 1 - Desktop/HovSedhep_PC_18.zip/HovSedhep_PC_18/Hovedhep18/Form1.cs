﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hovedhep18
{
    using static GlobalVariables;
    public partial class mainMenuForm : Form
    {
        public mainMenuForm()
        {
            InitializeComponent();
        }

        private void btnTableSeating_Click(object sender, EventArgs e)
        {
            seatingForm.MdiParent = this;
            seatingForm.Show();
            menuForm.Hide();
            historyForm.Hide();
            btnTableSeating.BackColor = Color.Aquamarine;
            btnMenu.BackColor = SystemColors.Control;
            btnHistory.BackColor = SystemColors.Control;
            
        }

        private void btnMenu_Click(object sender, EventArgs e)
        { 
            menuForm.MdiParent = this;
            menuForm.Show();
            seatingForm.Hide();
            historyForm.Hide();
            btnTableSeating.BackColor = SystemColors.Control;
            btnHistory.BackColor= SystemColors.Control;
            btnMenu.BackColor = Color.Aquamarine;  
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            historyForm.MdiParent = this;
            historyForm.Show();
            seatingForm.Hide();
            menuForm.Hide();
            btnHistory.BackColor = Color.Aquamarine;
            btnMenu.BackColor = SystemColors.Control;
            btnTableSeating.BackColor= SystemColors.Control;
            
        }
    }
}
