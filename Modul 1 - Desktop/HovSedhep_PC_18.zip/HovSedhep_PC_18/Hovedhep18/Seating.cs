﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hovedhep18
{
    public partial class SeatingForm : Form
    {
        public SeatingForm()
        {
            InitializeComponent();
        }

        private void btnTableA1_Click(object sender, EventArgs e)
        {
            AssignTableForm form = new AssignTableForm();
            form.ShowDialog();
            form.Text = "Assign Table - A1";
        }

        private void btnTableC1_Click(object sender, EventArgs e)
        {
            TableSeatingDetailForm form = new TableSeatingDetailForm();
            form.ShowDialog();
            form.Text = "Table Detail - C1";
        }

        private void btnTableA2_Click(object sender, EventArgs e)
        {
            AssignTableForm form = new AssignTableForm();
            form.ShowDialog();
            form.Text = "Assign Table - A2";
        }

        private void btnTableB1_Click(object sender, EventArgs e)
        {
            TableSeatingDetailForm form = new TableSeatingDetailForm();
            form.ShowDialog();
            form.Text = "Table Detail - B1";
        }

        private void btnTableB2_Click(object sender, EventArgs e)
        {
            AssignTableForm form = new AssignTableForm();
            form.ShowDialog();
            form.Text = "Assign Table - B2";
        }

        private void btnTableA3_Click(object sender, EventArgs e)
        {
            AssignTableForm form = new AssignTableForm();
            form.ShowDialog();
            form.Text = "Assign Table - A3";
        }

        private void btnTableC2_Click(object sender, EventArgs e)
        {
            AssignTableForm form = new AssignTableForm();
            form.ShowDialog();
            form.Text = "Assign Table - C2";
        }

        private void btnTableA4_Click(object sender, EventArgs e)
        {
            AssignTableForm form = new AssignTableForm();
            form.ShowDialog();
            form.Text = "Assign Table - A4";
        }
    }
}
