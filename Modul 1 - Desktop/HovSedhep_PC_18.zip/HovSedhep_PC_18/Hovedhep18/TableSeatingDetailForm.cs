﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hovedhep18
{
    using static GlobalVariables;
    public partial class TableSeatingDetailForm : Form
    {
        public TableSeatingDetailForm()
        {
            InitializeComponent();
        }

        private void btnCancelTable_Click(object sender, EventArgs e)
        {
            textBoxWaitress.Text = string.Empty;
            textBoxCustomerName.Text = string.Empty;
            textBoxPaxSize.Text = string.Empty;
            //Remove The Data From The Table Order
        }

        private void btnFinishTable_Click(object sender, EventArgs e)
        {
            mainMenuForm form = new mainMenuForm();
            form.Show();
            this.Hide();
            //Finish The Table,Making It Unoccupied
        }

        private void TableSeatingDetailForm_Load(object sender, EventArgs e)
        {
            var roles = db.Employees.Select(x => x.Role.Contains("Waitress")).ToList();
        }
    }
}
