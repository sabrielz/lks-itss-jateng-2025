﻿namespace Hovedhep18
{
    partial class AssignTableForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxCustomerName = new System.Windows.Forms.TextBox();
            this.numericPaxSize = new System.Windows.Forms.NumericUpDown();
            this.comboBoxWaitressName = new System.Windows.Forms.ComboBox();
            this.hovSedhepDatabaseDataSet = new Hovedhep18.HovSedhepDatabaseDataSet();
            this.employeesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeesTableAdapter = new Hovedhep18.HovSedhepDatabaseDataSetTableAdapters.EmployeesTableAdapter();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericPaxSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hovSedhepDatabaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Waitress";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Customer Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Pax Size";
            // 
            // textBoxCustomerName
            // 
            this.textBoxCustomerName.Location = new System.Drawing.Point(153, 121);
            this.textBoxCustomerName.Name = "textBoxCustomerName";
            this.textBoxCustomerName.Size = new System.Drawing.Size(158, 22);
            this.textBoxCustomerName.TabIndex = 3;
            // 
            // numericPaxSize
            // 
            this.numericPaxSize.Location = new System.Drawing.Point(153, 183);
            this.numericPaxSize.Name = "numericPaxSize";
            this.numericPaxSize.Size = new System.Drawing.Size(158, 22);
            this.numericPaxSize.TabIndex = 4;
            // 
            // comboBoxWaitressName
            // 
            this.comboBoxWaitressName.AutoCompleteCustomSource.AddRange(new string[] {
            "Nuni Santika"});
            this.comboBoxWaitressName.FormattingEnabled = true;
            this.comboBoxWaitressName.Items.AddRange(new object[] {
            "Rizky Hidayat",
            "Siti Aminah",
            "Nuni Santika",
            "Lisa Permata",
            "Farah Wijaya"});
            this.comboBoxWaitressName.Location = new System.Drawing.Point(153, 58);
            this.comboBoxWaitressName.Name = "comboBoxWaitressName";
            this.comboBoxWaitressName.Size = new System.Drawing.Size(158, 24);
            this.comboBoxWaitressName.TabIndex = 5;
            this.comboBoxWaitressName.SelectedIndexChanged += new System.EventHandler(this.comboBoxWaitressName_SelectedIndexChanged);
            // 
            // hovSedhepDatabaseDataSet
            // 
            this.hovSedhepDatabaseDataSet.DataSetName = "HovSedhepDatabaseDataSet";
            this.hovSedhepDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeesBindingSource
            // 
            this.employeesBindingSource.DataMember = "Employees";
            this.employeesBindingSource.DataSource = this.hovSedhepDatabaseDataSet;
            // 
            // employeesTableAdapter
            // 
            this.employeesTableAdapter.ClearBeforeFill = true;
            // 
            // btnOk
            // 
            this.btnOk.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnOk.Location = new System.Drawing.Point(46, 233);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(101, 35);
            this.btnOk.TabIndex = 6;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancel.Location = new System.Drawing.Point(186, 233);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(102, 35);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // AssignTableForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 290);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.comboBoxWaitressName);
            this.Controls.Add(this.numericPaxSize);
            this.Controls.Add(this.textBoxCustomerName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AssignTableForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AssignTableFormcs";
            this.Load += new System.EventHandler(this.AssignTableFormcs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericPaxSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hovSedhepDatabaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxCustomerName;
        private System.Windows.Forms.NumericUpDown numericPaxSize;
        private System.Windows.Forms.ComboBox comboBoxWaitressName;
        private HovSedhepDatabaseDataSet hovSedhepDatabaseDataSet;
        private System.Windows.Forms.BindingSource employeesBindingSource;
        private HovSedhepDatabaseDataSetTableAdapters.EmployeesTableAdapter employeesTableAdapter;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
    }
}