﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hovedhep18
{
    using static GlobalVariables;
    public partial class HistoryForm : Form
    {
        public HistoryForm()
        {
            InitializeComponent();
        }

        private void HistoryForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hovSedhepDatabaseDataSet2.RestaurantTables' table. You can move, or remove it, as needed.
            this.restaurantTablesTableAdapter.Fill(this.hovSedhepDatabaseDataSet2.RestaurantTables);
            this.loadData();
        }

        private void groupBoxTransaction_Enter(object sender, EventArgs e)
        {

        }
        public void loadData()
        {
            transactionGridView.Rows.Clear();
            orderDetailsGridView.Rows.Clear();
            orderGridView.Rows.Clear();
            int id = 0;
            db.Transactions.ToList().ForEach(d =>
            {
                var transactionId = d.TransactionID;
                var tableName = db.RestaurantTables.Where(j => j.TableID == d.TableID).Select(j => j.Name).FirstOrDefault();
                var customerName = d.CustomerName;
                var date = d.TransactionDate;
                var totalPrice = "56000";
                object[] obj = new object[] { transactionId, tableName, customerName, date, totalPrice };
                transactionGridView.Rows.Add(obj);
            });
            db.Orders.ToList().ForEach(d =>
            {
                var transactionID = d.TransactionID;
                var orderID = d.OrderID;
                var orderTime = DateTime.Parse(d.OrderTime.ToString());
                var inputBy = "Rizki Hidayat";
                var numberitems = 4;
                object[] obj = new object[] { transactionID, orderID, orderTime.ToString("HH:mm:ss"), inputBy, numberitems };
                orderGridView.Rows.Add(obj);
            });
            db.OrderDetails.ToList().ForEach(d =>
            {
                var itemPrice = db.MenuItems.Select(c => c.Price).FirstOrDefault();
                var orderID = d.OrderID;
                var orderDetailId = d.OrderDetailID;
                var menuName = db.MenuItems.Where(j => j.MenuItemID == d.MenuItemID).Select(j => j.Name).FirstOrDefault();
                var quantity = 6;
                var price = quantity * itemPrice;
                object[] obj = new object[] { orderID, orderDetailId, menuName, quantity, price };
                orderDetailsGridView.Rows.Add(obj);
            });
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            loadData();
        }
    }
}
