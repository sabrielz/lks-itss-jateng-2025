﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hovedhep18
{
    using static GlobalVariables;
    public partial class AssignTableForm : Form
    {
        public AssignTableForm()
        {
            InitializeComponent();
        }

        private void AssignTableFormcs_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hovSedhepDatabaseDataSet.Employees' table. You can move, or remove it, as needed.
            this.employeesTableAdapter.Fill(this.hovSedhepDatabaseDataSet.Employees);

        }

        private void comboBoxWaitressName_SelectedIndexChanged(object sender, EventArgs e)
        {
            var waitresses = db.Employees.Where(d => d.Role.Contains("Waitress"));
        }
        private void btnOk_Click(object sender, EventArgs e)
        { 
            var customerName = db.Transactions.Where(d => d.CustomerName == textBoxCustomerName.Text).FirstOrDefault();
            if (comboBoxWaitressName.SelectedIndex == -1)
            {
                MessageBox.Show("Please Enter The Waitress Name");
            }
            if (numericPaxSize.Value == 0)
            {
                MessageBox.Show("Please Enter A Capacity");
            }
            if (customerName.CustomerName != null)
            {
                MessageBox.Show("Please Enter The Customer Name");
            }
            
            db.SaveChanges();
            mainMenuForm form = new mainMenuForm();
            form.Show();
            this.Hide();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            comboBoxWaitressName.SelectedIndex = -1;
            textBoxCustomerName.Text = string.Empty;
            numericPaxSize.Value = 0;
        }
    }
}
