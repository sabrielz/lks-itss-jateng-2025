﻿namespace Hovedhep18
{
    partial class TableSeatingDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxWaitress = new System.Windows.Forms.TextBox();
            this.textBoxCustomerName = new System.Windows.Forms.TextBox();
            this.textBoxPaxSize = new System.Windows.Forms.TextBox();
            this.btnCancelTable = new System.Windows.Forms.Button();
            this.btnFinishTable = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Waitress";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Customer Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Pax Size";
            // 
            // textBoxWaitress
            // 
            this.textBoxWaitress.Location = new System.Drawing.Point(156, 91);
            this.textBoxWaitress.Name = "textBoxWaitress";
            this.textBoxWaitress.ReadOnly = true;
            this.textBoxWaitress.Size = new System.Drawing.Size(204, 22);
            this.textBoxWaitress.TabIndex = 3;
            this.textBoxWaitress.Text = "Nuni Santika";
            // 
            // textBoxCustomerName
            // 
            this.textBoxCustomerName.Location = new System.Drawing.Point(156, 160);
            this.textBoxCustomerName.Name = "textBoxCustomerName";
            this.textBoxCustomerName.ReadOnly = true;
            this.textBoxCustomerName.Size = new System.Drawing.Size(204, 22);
            this.textBoxCustomerName.TabIndex = 4;
            this.textBoxCustomerName.Text = "David Lee";
            // 
            // textBoxPaxSize
            // 
            this.textBoxPaxSize.Location = new System.Drawing.Point(156, 225);
            this.textBoxPaxSize.Name = "textBoxPaxSize";
            this.textBoxPaxSize.ReadOnly = true;
            this.textBoxPaxSize.Size = new System.Drawing.Size(204, 22);
            this.textBoxPaxSize.TabIndex = 5;
            this.textBoxPaxSize.Text = "3";
            // 
            // btnCancelTable
            // 
            this.btnCancelTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCancelTable.Location = new System.Drawing.Point(22, 291);
            this.btnCancelTable.Name = "btnCancelTable";
            this.btnCancelTable.Size = new System.Drawing.Size(133, 33);
            this.btnCancelTable.TabIndex = 6;
            this.btnCancelTable.Text = "Cancel Table";
            this.btnCancelTable.UseVisualStyleBackColor = false;
            this.btnCancelTable.Click += new System.EventHandler(this.btnCancelTable_Click);
            // 
            // btnFinishTable
            // 
            this.btnFinishTable.BackColor = System.Drawing.Color.Lime;
            this.btnFinishTable.Location = new System.Drawing.Point(200, 291);
            this.btnFinishTable.Name = "btnFinishTable";
            this.btnFinishTable.Size = new System.Drawing.Size(133, 33);
            this.btnFinishTable.TabIndex = 7;
            this.btnFinishTable.Text = "Finish Table";
            this.btnFinishTable.UseVisualStyleBackColor = false;
            this.btnFinishTable.Click += new System.EventHandler(this.btnFinishTable_Click);
            // 
            // TableSeatingDetailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 359);
            this.Controls.Add(this.btnFinishTable);
            this.Controls.Add(this.btnCancelTable);
            this.Controls.Add(this.textBoxPaxSize);
            this.Controls.Add(this.textBoxCustomerName);
            this.Controls.Add(this.textBoxWaitress);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "TableSeatingDetailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TableSeatingDetailForm";
            this.Load += new System.EventHandler(this.TableSeatingDetailForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxWaitress;
        private System.Windows.Forms.TextBox textBoxCustomerName;
        private System.Windows.Forms.TextBox textBoxPaxSize;
        private System.Windows.Forms.Button btnCancelTable;
        private System.Windows.Forms.Button btnFinishTable;
    }
}