﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hovedhep18
{
    internal class GlobalVariables
    {
        public static HovSedhepDatabaseEntities db = new HovSedhepDatabaseEntities();
        public static SeatingForm seatingForm = new SeatingForm();
        public static MenuForm menuForm = new MenuForm();
        public static HistoryForm historyForm = new HistoryForm();
    }
}
