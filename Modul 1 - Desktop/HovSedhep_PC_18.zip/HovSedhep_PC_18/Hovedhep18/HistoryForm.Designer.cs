﻿namespace Hovedhep18
{
    partial class HistoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.filterBox = new System.Windows.Forms.GroupBox();
            this.btnApply = new System.Windows.Forms.Button();
            this.comboBoxTableName = new System.Windows.Forms.ComboBox();
            this.restaurantTablesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hovSedhepDatabaseDataSet2 = new Hovedhep18.HovSedhepDatabaseDataSet2();
            this.dateTimePick = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxOrder = new System.Windows.Forms.GroupBox();
            this.orderGridView = new System.Windows.Forms.DataGridView();
            this.transactionsId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inputBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numberItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBoxTransaction = new System.Windows.Forms.GroupBox();
            this.transactionGridView = new System.Windows.Forms.DataGridView();
            this.transactionId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBoxOrderDetails = new System.Windows.Forms.GroupBox();
            this.orderDetailsGridView = new System.Windows.Forms.DataGridView();
            this.ordersId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderDetailId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.restaurantTablesTableAdapter = new Hovedhep18.HovSedhepDatabaseDataSet2TableAdapters.RestaurantTablesTableAdapter();
            this.filterBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantTablesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hovSedhepDatabaseDataSet2)).BeginInit();
            this.groupBoxOrder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderGridView)).BeginInit();
            this.groupBoxTransaction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.transactionGridView)).BeginInit();
            this.groupBoxOrderDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderDetailsGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // filterBox
            // 
            this.filterBox.Controls.Add(this.btnApply);
            this.filterBox.Controls.Add(this.comboBoxTableName);
            this.filterBox.Controls.Add(this.dateTimePick);
            this.filterBox.Controls.Add(this.label2);
            this.filterBox.Controls.Add(this.label1);
            this.filterBox.Location = new System.Drawing.Point(27, 29);
            this.filterBox.Name = "filterBox";
            this.filterBox.Size = new System.Drawing.Size(1055, 111);
            this.filterBox.TabIndex = 0;
            this.filterBox.TabStop = false;
            this.filterBox.Text = "Filter";
            // 
            // btnApply
            // 
            this.btnApply.Location = new System.Drawing.Point(413, 65);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(85, 34);
            this.btnApply.TabIndex = 4;
            this.btnApply.Text = "Apply";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // comboBoxTableName
            // 
            this.comboBoxTableName.DataSource = this.restaurantTablesBindingSource;
            this.comboBoxTableName.DisplayMember = "Name";
            this.comboBoxTableName.FormattingEnabled = true;
            this.comboBoxTableName.Location = new System.Drawing.Point(139, 71);
            this.comboBoxTableName.Name = "comboBoxTableName";
            this.comboBoxTableName.Size = new System.Drawing.Size(247, 24);
            this.comboBoxTableName.TabIndex = 3;
            this.comboBoxTableName.ValueMember = "TableID";
            // 
            // restaurantTablesBindingSource
            // 
            this.restaurantTablesBindingSource.DataMember = "RestaurantTables";
            this.restaurantTablesBindingSource.DataSource = this.hovSedhepDatabaseDataSet2;
            // 
            // hovSedhepDatabaseDataSet2
            // 
            this.hovSedhepDatabaseDataSet2.DataSetName = "HovSedhepDatabaseDataSet2";
            this.hovSedhepDatabaseDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dateTimePick
            // 
            this.dateTimePick.Location = new System.Drawing.Point(139, 34);
            this.dateTimePick.Name = "dateTimePick";
            this.dateTimePick.Size = new System.Drawing.Size(247, 22);
            this.dateTimePick.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(31, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Table Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Date";
            // 
            // groupBoxOrder
            // 
            this.groupBoxOrder.Controls.Add(this.orderGridView);
            this.groupBoxOrder.Location = new System.Drawing.Point(27, 358);
            this.groupBoxOrder.Name = "groupBoxOrder";
            this.groupBoxOrder.Size = new System.Drawing.Size(1055, 173);
            this.groupBoxOrder.TabIndex = 1;
            this.groupBoxOrder.TabStop = false;
            this.groupBoxOrder.Text = "Order";
            // 
            // orderGridView
            // 
            this.orderGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.orderGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.transactionsId,
            this.orderId,
            this.orderTime,
            this.inputBy,
            this.numberItem});
            this.orderGridView.Location = new System.Drawing.Point(-1, 21);
            this.orderGridView.Name = "orderGridView";
            this.orderGridView.RowHeadersWidth = 51;
            this.orderGridView.RowTemplate.Height = 24;
            this.orderGridView.Size = new System.Drawing.Size(1042, 139);
            this.orderGridView.TabIndex = 0;
            // 
            // transactionsId
            // 
            this.transactionsId.HeaderText = "Transaction ID";
            this.transactionsId.MinimumWidth = 6;
            this.transactionsId.Name = "transactionsId";
            this.transactionsId.Width = 125;
            // 
            // orderId
            // 
            this.orderId.HeaderText = "Order ID";
            this.orderId.MinimumWidth = 6;
            this.orderId.Name = "orderId";
            this.orderId.Width = 125;
            // 
            // orderTime
            // 
            this.orderTime.HeaderText = "Order TIme";
            this.orderTime.MinimumWidth = 6;
            this.orderTime.Name = "orderTime";
            this.orderTime.Width = 125;
            // 
            // inputBy
            // 
            this.inputBy.HeaderText = "Input By Waitress";
            this.inputBy.MinimumWidth = 6;
            this.inputBy.Name = "inputBy";
            this.inputBy.Width = 125;
            // 
            // numberItem
            // 
            this.numberItem.HeaderText = "Numbers Of Items Ordered";
            this.numberItem.MinimumWidth = 6;
            this.numberItem.Name = "numberItem";
            this.numberItem.Width = 125;
            // 
            // groupBoxTransaction
            // 
            this.groupBoxTransaction.Controls.Add(this.transactionGridView);
            this.groupBoxTransaction.Location = new System.Drawing.Point(27, 172);
            this.groupBoxTransaction.Name = "groupBoxTransaction";
            this.groupBoxTransaction.Size = new System.Drawing.Size(1055, 166);
            this.groupBoxTransaction.TabIndex = 2;
            this.groupBoxTransaction.TabStop = false;
            this.groupBoxTransaction.Text = "Transaction";
            this.groupBoxTransaction.Enter += new System.EventHandler(this.groupBoxTransaction_Enter);
            // 
            // transactionGridView
            // 
            this.transactionGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.transactionGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.transactionId,
            this.tableName,
            this.customerName,
            this.date,
            this.totalPrice});
            this.transactionGridView.Location = new System.Drawing.Point(7, 22);
            this.transactionGridView.Name = "transactionGridView";
            this.transactionGridView.ReadOnly = true;
            this.transactionGridView.RowHeadersWidth = 51;
            this.transactionGridView.RowTemplate.Height = 24;
            this.transactionGridView.Size = new System.Drawing.Size(1042, 139);
            this.transactionGridView.TabIndex = 0;
            // 
            // transactionId
            // 
            this.transactionId.HeaderText = "Transaction Id";
            this.transactionId.MinimumWidth = 6;
            this.transactionId.Name = "transactionId";
            this.transactionId.ReadOnly = true;
            this.transactionId.Width = 125;
            // 
            // tableName
            // 
            this.tableName.HeaderText = "Table Name";
            this.tableName.MinimumWidth = 6;
            this.tableName.Name = "tableName";
            this.tableName.ReadOnly = true;
            this.tableName.Width = 125;
            // 
            // customerName
            // 
            this.customerName.HeaderText = "Customer Name";
            this.customerName.MinimumWidth = 6;
            this.customerName.Name = "customerName";
            this.customerName.ReadOnly = true;
            this.customerName.Width = 125;
            // 
            // date
            // 
            this.date.HeaderText = "Date";
            this.date.MinimumWidth = 6;
            this.date.Name = "date";
            this.date.ReadOnly = true;
            this.date.Width = 125;
            // 
            // totalPrice
            // 
            this.totalPrice.HeaderText = "Total Price";
            this.totalPrice.MinimumWidth = 6;
            this.totalPrice.Name = "totalPrice";
            this.totalPrice.ReadOnly = true;
            this.totalPrice.Width = 125;
            // 
            // groupBoxOrderDetails
            // 
            this.groupBoxOrderDetails.Controls.Add(this.orderDetailsGridView);
            this.groupBoxOrderDetails.Location = new System.Drawing.Point(20, 537);
            this.groupBoxOrderDetails.Name = "groupBoxOrderDetails";
            this.groupBoxOrderDetails.Size = new System.Drawing.Size(1055, 165);
            this.groupBoxOrderDetails.TabIndex = 3;
            this.groupBoxOrderDetails.TabStop = false;
            this.groupBoxOrderDetails.Text = "Order Details";
            // 
            // orderDetailsGridView
            // 
            this.orderDetailsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.orderDetailsGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ordersId,
            this.orderDetailId,
            this.menuName,
            this.quantity,
            this.price});
            this.orderDetailsGridView.Location = new System.Drawing.Point(7, 22);
            this.orderDetailsGridView.Name = "orderDetailsGridView";
            this.orderDetailsGridView.RowHeadersWidth = 51;
            this.orderDetailsGridView.RowTemplate.Height = 24;
            this.orderDetailsGridView.Size = new System.Drawing.Size(1042, 136);
            this.orderDetailsGridView.TabIndex = 0;
            // 
            // ordersId
            // 
            this.ordersId.HeaderText = "Order ID";
            this.ordersId.MinimumWidth = 6;
            this.ordersId.Name = "ordersId";
            this.ordersId.Width = 125;
            // 
            // orderDetailId
            // 
            this.orderDetailId.HeaderText = "Order Details Id";
            this.orderDetailId.MinimumWidth = 6;
            this.orderDetailId.Name = "orderDetailId";
            this.orderDetailId.Width = 125;
            // 
            // menuName
            // 
            this.menuName.HeaderText = "Menu Name";
            this.menuName.MinimumWidth = 6;
            this.menuName.Name = "menuName";
            this.menuName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.menuName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.menuName.Width = 125;
            // 
            // quantity
            // 
            this.quantity.HeaderText = "Quantity";
            this.quantity.MinimumWidth = 6;
            this.quantity.Name = "quantity";
            this.quantity.Width = 125;
            // 
            // price
            // 
            this.price.HeaderText = "Price";
            this.price.MinimumWidth = 6;
            this.price.Name = "price";
            this.price.Width = 125;
            // 
            // restaurantTablesTableAdapter
            // 
            this.restaurantTablesTableAdapter.ClearBeforeFill = true;
            // 
            // HistoryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 733);
            this.Controls.Add(this.groupBoxOrderDetails);
            this.Controls.Add(this.groupBoxTransaction);
            this.Controls.Add(this.groupBoxOrder);
            this.Controls.Add(this.filterBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "HistoryForm";
            this.Text = "HistoryForm";
            this.Load += new System.EventHandler(this.HistoryForm_Load);
            this.filterBox.ResumeLayout(false);
            this.filterBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantTablesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hovSedhepDatabaseDataSet2)).EndInit();
            this.groupBoxOrder.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.orderGridView)).EndInit();
            this.groupBoxTransaction.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.transactionGridView)).EndInit();
            this.groupBoxOrderDetails.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.orderDetailsGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox filterBox;
        private System.Windows.Forms.GroupBox groupBoxOrder;
        private System.Windows.Forms.GroupBox groupBoxTransaction;
        private System.Windows.Forms.GroupBox groupBoxOrderDetails;
        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.ComboBox comboBoxTableName;
        private System.Windows.Forms.DateTimePicker dateTimePick;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private HovSedhepDatabaseDataSet2 hovSedhepDatabaseDataSet2;
        private System.Windows.Forms.BindingSource restaurantTablesBindingSource;
        private HovSedhepDatabaseDataSet2TableAdapters.RestaurantTablesTableAdapter restaurantTablesTableAdapter;
        private System.Windows.Forms.DataGridView orderGridView;
        private System.Windows.Forms.DataGridView transactionGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionId;
        private System.Windows.Forms.DataGridViewTextBoxColumn tableName;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn date;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalPrice;
        private System.Windows.Forms.DataGridView orderDetailsGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionsId;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderId;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn inputBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ordersId;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderDetailId;
        private System.Windows.Forms.DataGridViewTextBoxColumn menuName;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
    }
}