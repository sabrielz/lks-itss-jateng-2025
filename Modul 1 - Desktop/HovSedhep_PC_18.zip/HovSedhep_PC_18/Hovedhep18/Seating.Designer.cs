﻿namespace Hovedhep18
{
    partial class SeatingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnTableA4 = new System.Windows.Forms.Button();
            this.btnTableC2 = new System.Windows.Forms.Button();
            this.btnTableA3 = new System.Windows.Forms.Button();
            this.btnTableB2 = new System.Windows.Forms.Button();
            this.btnTableB1 = new System.Windows.Forms.Button();
            this.btnTableA2 = new System.Windows.Forms.Button();
            this.btnTableC1 = new System.Windows.Forms.Button();
            this.btnTableA1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnTableA4);
            this.groupBox1.Controls.Add(this.btnTableC2);
            this.groupBox1.Controls.Add(this.btnTableA3);
            this.groupBox1.Controls.Add(this.btnTableB2);
            this.groupBox1.Controls.Add(this.btnTableB1);
            this.groupBox1.Controls.Add(this.btnTableA2);
            this.groupBox1.Controls.Add(this.btnTableC1);
            this.groupBox1.Controls.Add(this.btnTableA1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(882, 475);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Table Seating";
            // 
            // btnTableA4
            // 
            this.btnTableA4.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTableA4.Location = new System.Drawing.Point(721, 339);
            this.btnTableA4.Name = "btnTableA4";
            this.btnTableA4.Size = new System.Drawing.Size(140, 111);
            this.btnTableA4.TabIndex = 7;
            this.btnTableA4.Text = "A4";
            this.btnTableA4.UseVisualStyleBackColor = true;
            this.btnTableA4.Click += new System.EventHandler(this.btnTableA4_Click);
            // 
            // btnTableC2
            // 
            this.btnTableC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTableC2.Location = new System.Drawing.Point(203, 339);
            this.btnTableC2.Name = "btnTableC2";
            this.btnTableC2.Size = new System.Drawing.Size(492, 111);
            this.btnTableC2.TabIndex = 6;
            this.btnTableC2.Text = "C2";
            this.btnTableC2.UseVisualStyleBackColor = true;
            this.btnTableC2.Click += new System.EventHandler(this.btnTableC2_Click);
            // 
            // btnTableA3
            // 
            this.btnTableA3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTableA3.Location = new System.Drawing.Point(7, 339);
            this.btnTableA3.Name = "btnTableA3";
            this.btnTableA3.Size = new System.Drawing.Size(140, 111);
            this.btnTableA3.TabIndex = 5;
            this.btnTableA3.Text = "A3";
            this.btnTableA3.UseVisualStyleBackColor = true;
            this.btnTableA3.Click += new System.EventHandler(this.btnTableA3_Click);
            // 
            // btnTableB2
            // 
            this.btnTableB2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTableB2.Location = new System.Drawing.Point(442, 191);
            this.btnTableB2.Name = "btnTableB2";
            this.btnTableB2.Size = new System.Drawing.Size(419, 111);
            this.btnTableB2.TabIndex = 4;
            this.btnTableB2.Text = "B2";
            this.btnTableB2.UseVisualStyleBackColor = true;
            this.btnTableB2.Click += new System.EventHandler(this.btnTableB2_Click);
            // 
            // btnTableB1
            // 
            this.btnTableB1.BackColor = System.Drawing.Color.Gold;
            this.btnTableB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTableB1.Location = new System.Drawing.Point(7, 191);
            this.btnTableB1.Name = "btnTableB1";
            this.btnTableB1.Size = new System.Drawing.Size(419, 111);
            this.btnTableB1.TabIndex = 3;
            this.btnTableB1.Text = "B1";
            this.btnTableB1.UseVisualStyleBackColor = false;
            this.btnTableB1.Click += new System.EventHandler(this.btnTableB1_Click);
            // 
            // btnTableA2
            // 
            this.btnTableA2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTableA2.Location = new System.Drawing.Point(721, 29);
            this.btnTableA2.Name = "btnTableA2";
            this.btnTableA2.Size = new System.Drawing.Size(140, 111);
            this.btnTableA2.TabIndex = 2;
            this.btnTableA2.Text = "A2";
            this.btnTableA2.UseVisualStyleBackColor = true;
            this.btnTableA2.Click += new System.EventHandler(this.btnTableA2_Click);
            // 
            // btnTableC1
            // 
            this.btnTableC1.BackColor = System.Drawing.Color.Gold;
            this.btnTableC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTableC1.Location = new System.Drawing.Point(203, 22);
            this.btnTableC1.Name = "btnTableC1";
            this.btnTableC1.Size = new System.Drawing.Size(492, 111);
            this.btnTableC1.TabIndex = 1;
            this.btnTableC1.Text = "C1";
            this.btnTableC1.UseVisualStyleBackColor = false;
            this.btnTableC1.Click += new System.EventHandler(this.btnTableC1_Click);
            // 
            // btnTableA1
            // 
            this.btnTableA1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTableA1.Location = new System.Drawing.Point(7, 29);
            this.btnTableA1.Name = "btnTableA1";
            this.btnTableA1.Size = new System.Drawing.Size(140, 111);
            this.btnTableA1.TabIndex = 0;
            this.btnTableA1.Text = "A1";
            this.btnTableA1.UseVisualStyleBackColor = true;
            this.btnTableA1.Click += new System.EventHandler(this.btnTableA1_Click);
            // 
            // SeatingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(907, 500);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SeatingForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Seating";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnTableA4;
        private System.Windows.Forms.Button btnTableC2;
        private System.Windows.Forms.Button btnTableA3;
        private System.Windows.Forms.Button btnTableB2;
        private System.Windows.Forms.Button btnTableB1;
        private System.Windows.Forms.Button btnTableA2;
        private System.Windows.Forms.Button btnTableC1;
        private System.Windows.Forms.Button btnTableA1;
    }
}