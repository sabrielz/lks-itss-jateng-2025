﻿namespace API_PC_18.Models
{
    public class CoursesDto
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int Duration { get; set; }
        public Array Modules { get; set; }
    }
}
