﻿namespace API_PC_18.Models
{
    public class CouponsDto2
    {

    }
}
