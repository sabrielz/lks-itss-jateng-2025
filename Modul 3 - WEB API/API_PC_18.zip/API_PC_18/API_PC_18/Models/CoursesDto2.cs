﻿namespace API_PC_18.Models
{
    public class CoursesDto2
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string Instructor { get; set; }
        public int Duration { get; set; }
        public Array Modules { get; set; }
        public string Active { get; set; }
    }
}
