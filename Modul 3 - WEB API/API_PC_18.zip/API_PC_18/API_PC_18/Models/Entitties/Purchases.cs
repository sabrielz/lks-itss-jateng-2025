﻿namespace API_PC_18.Models.Entitties
{
    public class Purchases
    {
        public  int Id { get; set; }
        public int UserId { get; set; }
        public int CourseId { get; set; }
        public int CouponId { get; set; }
        public decimal PricePaid { get; set; }
        public string PaymentMethod { get; set; }
        public DateTime PurchasedAt { get; set; }
    }
}
