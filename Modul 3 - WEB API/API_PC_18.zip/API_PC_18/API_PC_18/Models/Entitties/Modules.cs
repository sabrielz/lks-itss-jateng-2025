﻿namespace API_PC_18.Models.Entitties
{
    public class Modules
    {
        public int Id { get; set; }
        public int CourseId { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
