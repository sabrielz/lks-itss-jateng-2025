﻿namespace API_PC_18.Models.Entitties
{
    public class Courses
    {
        public int Id { get; set; }
        public string Titles { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int Duration { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
