﻿namespace API_PC_18.Models.Entitties
{
    public class Coupons
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public decimal DiscountPercent {  get; set; }
        public int Quota { get; set; }
        public DateTime ExpiryDate { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
