﻿namespace API_PC_18.Models.Entitties
{
    public class CouponsDto
    {
        public string CouponCode { get; set; }
        public decimal DiscountPercent { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int Quota { get; set; }
    }
}
