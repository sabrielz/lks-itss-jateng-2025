﻿namespace API_PC_18.Models
{
    public class PurchasesDto
    {
        public string PaymentMethod { get; set; }
        public string CouponCode { get; set; }
    }
}
