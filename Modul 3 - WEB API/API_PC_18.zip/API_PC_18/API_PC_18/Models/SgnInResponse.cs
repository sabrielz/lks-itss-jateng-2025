﻿namespace API_PC_18.Models
{
    public class SignInResponse
    {
        public string Token {  get; set; }  
    }
}
