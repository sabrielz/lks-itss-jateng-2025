﻿namespace API_PC_18.Services
{
    public class JwtServices
    {
        public void GenerateToken()
        {
            
        }
    }
}
