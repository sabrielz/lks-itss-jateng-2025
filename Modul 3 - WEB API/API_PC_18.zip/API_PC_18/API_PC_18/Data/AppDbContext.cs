﻿using API_PC_18.Models.Entitties;
using Microsoft.EntityFrameworkCore;

namespace API_PC_18.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(AppDbContext DbContext, DbContextOptions options)
        {
        }
        DbSet<Users> Users { get; set; }
    }
}
