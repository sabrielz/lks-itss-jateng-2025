﻿using API_PC_18.Data;
using API_PC_18.Models;
using API_PC_18.Models.Entitties;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_PC_18.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetCourses()
        {
            Courses course = new Courses
            {
                Id = 1,
                Titles = "Introduction To C#",
                Description = "Learn the basics of C# programming including syntax and OOP concepts",
                Price = Convert.ToDecimal(99.99),
                Duration = 300,
            };

            return Ok(course);
        }

        [HttpPost]
        public IActionResult PayForBook(int id, [FromBody]  PurchasesDto pay)
        {

            Purchases purchase = new Purchases
            {
                Id = 12345,
                CourseId = 1,
                UserId = 1,
                PurchasedAt = DateTime.Now,
                PaymentMethod = pay.PaymentMethod,
                PricePaid = Convert.ToDecimal(99.99)
            };


            return Ok(purchase);
        }


    }
}
