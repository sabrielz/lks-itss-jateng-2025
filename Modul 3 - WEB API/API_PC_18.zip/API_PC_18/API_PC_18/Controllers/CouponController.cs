﻿using API_PC_18.Data;
using API_PC_18.Models;
using API_PC_18.Models.Entitties;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_PC_18.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CouponController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetCoupons()
        {
            Coupons coupom = new Coupons
            {
                Id = 1,
                Code = "SpringSale",
                DiscountPercent = 20,
                ExpiryDate = DateTime.Now.AddDays(7),
                Quota = 100
            };

            return Ok(coupom);
        }

        //[HttpPost]
        //public IActionResult MakeCoupons([FromBody] CouponsDto coupons)
        //{
        //    if (coupons.Quota < 0)
        //    {
        //        return NotFound();
        //    }

            

        //    return Ok(coupons);
        //}

        ////[HttpPut]
        ////public IActionResult UpdateCoupons(int id, [FromBody]  CouponsDto coupons)
        ////{
            


        ////    return Ok(coupo);
        

        //[HttpPost]
        //public IActionResult AddCourse([FromBody] CoursesDto courses)
        //{
        //    if (courses.Price != 0 )
        //    {
        //        return NotFound();
        //    }

        //    return Ok(new { message = "You Have Succesfully Added A Course" + courses });
        //}

        [HttpPut]
        public IActionResult UpdateCourses(int id, [FromBody] CoursesDto2 course)
        {
            return Ok(new { message = "Course Updated Succesfully" + course });
        }
    }
}
