﻿using API_PC_18.Data;
using API_PC_18.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_PC_18.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        public readonly AppDbContext _dbContext;
        public AuthController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        //[HttpPost("Users/Register")]
        //public IActionResult RegisterUsers([FromBody] SignInRequest username)
        //{
        //    return Ok(username);
        //}
        //[HttpPost("Users/Login")]
        //public IActionResult Login([FromBody] SignInRequest user)
        //{
        //    return Ok(user);
        //}
        //[HttpPost("Users/LogOut")]
        //public IActionResult Logout([FromBody] SignInResponse token)
        //{
        //    if (token != null)
        //    {
        //        return BadRequest();
        //    }

        //    return Ok(new { message = "logout Succesful" });

        //}
    }
}
