package com.lks.gawe_pc_18

object AppConfig {
    const val APP_BASE_URL = "http://localhost:5000"
    const val APP_SHARED_PREFERENCES_NAME = "prefs"
    const val APP_TOKEN_KEY = "token"
    const val APP_USER_KEY = "user"
}

